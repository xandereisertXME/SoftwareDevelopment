﻿namespace EXTRA_199_E2_S17
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pricesListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.meanPriceOutputLbl = new System.Windows.Forms.Label();
            this.calcMeanBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pricesListBox
            // 
            this.pricesListBox.FormattingEnabled = true;
            this.pricesListBox.Location = new System.Drawing.Point(89, 17);
            this.pricesListBox.Name = "pricesListBox";
            this.pricesListBox.Size = new System.Drawing.Size(120, 134);
            this.pricesListBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mean Price:";
            // 
            // meanPriceOutputLbl
            // 
            this.meanPriceOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.meanPriceOutputLbl.Location = new System.Drawing.Point(89, 158);
            this.meanPriceOutputLbl.Name = "meanPriceOutputLbl";
            this.meanPriceOutputLbl.Size = new System.Drawing.Size(120, 25);
            this.meanPriceOutputLbl.TabIndex = 2;
            this.meanPriceOutputLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcMeanBtn
            // 
            this.calcMeanBtn.Location = new System.Drawing.Point(89, 186);
            this.calcMeanBtn.Name = "calcMeanBtn";
            this.calcMeanBtn.Size = new System.Drawing.Size(120, 23);
            this.calcMeanBtn.TabIndex = 3;
            this.calcMeanBtn.Text = "Calculate Mean";
            this.calcMeanBtn.UseVisualStyleBackColor = true;
            this.calcMeanBtn.Click += new System.EventHandler(this.calcMeanBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 221);
            this.Controls.Add(this.calcMeanBtn);
            this.Controls.Add(this.meanPriceOutputLbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pricesListBox);
            this.Name = "Form1";
            this.Text = "Exam 2 EXTRA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox pricesListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label meanPriceOutputLbl;
        private System.Windows.Forms.Button calcMeanBtn;
    }
}

