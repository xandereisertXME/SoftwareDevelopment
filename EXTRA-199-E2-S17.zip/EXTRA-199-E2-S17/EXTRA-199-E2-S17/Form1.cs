﻿// CIS 199-02
// Spring 2017
// Exam 2, Part 3 - EXTRA CREDIT
// Grading ID: B8994

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EXTRA_199_E2_S17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        public decimal CalcMean(decimal[] array)
        {
            decimal sum = 0;
            for (int i=0; i < array.Length; i++)
            {
                sum += array[i];
            }

            return (sum / array.Length);
        }
        // CalcMean - returns a decimal and accepts an array of decimals as parameter
        //            Calculate and return the mean of values in array (sum divided by length)
        //            MUST WRITE OWN LOOP

        
        private void calcMeanBtn_Click(object sender, EventArgs e)
        {
            // Product prices
            decimal[] prices = { 99.99m, 105.00m, 100.00m, 102.25m, 97.97m,
                101.99m, 100.25m, 95.96m, 99.95m, 103.99m };
            decimal mean;

            pricesListBox.Items.Clear();

            for (int i = 0; i < prices.Length; i++)
            {
                pricesListBox.Items.Add(prices[i]);
            }
            // Display array of prices using pricesListBox
            // Each value in array must get added into the listbox's Items
            // and expressed as a string with currency formatting
            // MUST WRITE OWN LOOP

            mean = CalcMean(prices);
            // Call method CalcMean and store result in mean variable

            meanPriceOutputLbl.Text = mean.ToString("c");
            // Display mean using meanPriceOutputLbl with currency formatting

        }
    }
}
