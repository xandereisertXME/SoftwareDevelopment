﻿namespace Lab1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelID = new System.Windows.Forms.Label();
            this.buttonHobbies = new System.Windows.Forms.Button();
            this.buttonBook = new System.Windows.Forms.Button();
            this.buttonMovie = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(267, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(410, 376);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.labelID.Location = new System.Drawing.Point(399, 403);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(147, 51);
            this.labelID.TabIndex = 1;
            this.labelID.Text = "B8994";
            // 
            // buttonHobbies
            // 
            this.buttonHobbies.Location = new System.Drawing.Point(77, 496);
            this.buttonHobbies.Name = "buttonHobbies";
            this.buttonHobbies.Size = new System.Drawing.Size(215, 72);
            this.buttonHobbies.TabIndex = 2;
            this.buttonHobbies.Text = "Hobbies";
            this.buttonHobbies.UseVisualStyleBackColor = true;
            this.buttonHobbies.Click += new System.EventHandler(this.buttonHobbies_Click);
            // 
            // buttonBook
            // 
            this.buttonBook.Location = new System.Drawing.Point(365, 496);
            this.buttonBook.Name = "buttonBook";
            this.buttonBook.Size = new System.Drawing.Size(215, 72);
            this.buttonBook.TabIndex = 3;
            this.buttonBook.Text = "Book";
            this.buttonBook.UseVisualStyleBackColor = true;
            this.buttonBook.Click += new System.EventHandler(this.buttonBook_Click);
            // 
            // buttonMovie
            // 
            this.buttonMovie.Location = new System.Drawing.Point(651, 496);
            this.buttonMovie.Name = "buttonMovie";
            this.buttonMovie.Size = new System.Drawing.Size(215, 72);
            this.buttonMovie.TabIndex = 4;
            this.buttonMovie.Text = "Movie";
            this.buttonMovie.UseVisualStyleBackColor = true;
            this.buttonMovie.Click += new System.EventHandler(this.buttonMovie_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 613);
            this.Controls.Add(this.buttonMovie);
            this.Controls.Add(this.buttonBook);
            this.Controls.Add(this.buttonHobbies);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Lab 1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Button buttonHobbies;
        private System.Windows.Forms.Button buttonBook;
        private System.Windows.Forms.Button buttonMovie;
    }
}

