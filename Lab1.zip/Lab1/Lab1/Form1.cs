﻿// ID: B8994
// Lab 1
// Due: 29 January 2017
// CIS 199-02

// Description: This program consists of a picture of my favorite "animal" (the joke
// here is that I've included the character Animal from The Muppets) and three buttons.
// When clicked, the buttons each bring up a different message box that corresponds
// to the button's text. The Hobbies button displays some of my favorite hobbies,
// the Book button displays my favorite book, and the Movies button displays my
// favorite movie.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonHobbies_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Some of my favorite hobbies include singing, acting, listening to music and napping. I also love to pet my dogs, Max and Mabel.");
        }

        private void buttonBook_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite book is No Country for Old Men by Cormac McCarthy.");
        }

        private void buttonMovie_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite movie is Back to the Future II. Not the first one, not the third one, but the second one.");
        }
    }
}
