﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.preferredTitleLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.preferredTitleTextBox = new System.Windows.Forms.TextBox();
            this.nameOutputLabel = new System.Windows.Forms.Label();
            this.formatOneButton = new System.Windows.Forms.Button();
            this.formatTwoButton = new System.Windows.Forms.Button();
            this.formatThreeButton = new System.Windows.Forms.Button();
            this.formatFourButton = new System.Windows.Forms.Button();
            this.formatFiveButton = new System.Windows.Forms.Button();
            this.formatSixButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(283, 55);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(122, 25);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(261, 110);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(144, 25);
            this.middleNameLabel.TabIndex = 1;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(284, 166);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(121, 25);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // preferredTitleLabel
            // 
            this.preferredTitleLabel.AutoSize = true;
            this.preferredTitleLabel.Location = new System.Drawing.Point(12, 220);
            this.preferredTitleLabel.Name = "preferredTitleLabel";
            this.preferredTitleLabel.Size = new System.Drawing.Size(393, 25);
            this.preferredTitleLabel.TabIndex = 3;
            this.preferredTitleLabel.Text = "Preferred Title (Mr., Mrs., Ms., Dr., etc.):";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(463, 55);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(250, 31);
            this.firstNameTextBox.TabIndex = 4;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(463, 110);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(250, 31);
            this.middleNameTextBox.TabIndex = 5;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(463, 166);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(250, 31);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // preferredTitleTextBox
            // 
            this.preferredTitleTextBox.Location = new System.Drawing.Point(463, 220);
            this.preferredTitleTextBox.Name = "preferredTitleTextBox";
            this.preferredTitleTextBox.Size = new System.Drawing.Size(250, 31);
            this.preferredTitleTextBox.TabIndex = 7;
            // 
            // nameOutputLabel
            // 
            this.nameOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameOutputLabel.Location = new System.Drawing.Point(17, 316);
            this.nameOutputLabel.Name = "nameOutputLabel";
            this.nameOutputLabel.Size = new System.Drawing.Size(713, 60);
            this.nameOutputLabel.TabIndex = 8;
            this.nameOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formatOneButton
            // 
            this.formatOneButton.Location = new System.Drawing.Point(36, 389);
            this.formatOneButton.Name = "formatOneButton";
            this.formatOneButton.Size = new System.Drawing.Size(150, 50);
            this.formatOneButton.TabIndex = 9;
            this.formatOneButton.Text = "Format 1";
            this.formatOneButton.UseVisualStyleBackColor = true;
            this.formatOneButton.Click += new System.EventHandler(this.formatOneButton_Click);
            // 
            // formatTwoButton
            // 
            this.formatTwoButton.Location = new System.Drawing.Point(211, 389);
            this.formatTwoButton.Name = "formatTwoButton";
            this.formatTwoButton.Size = new System.Drawing.Size(150, 50);
            this.formatTwoButton.TabIndex = 10;
            this.formatTwoButton.Text = "Format 2";
            this.formatTwoButton.UseVisualStyleBackColor = true;
            this.formatTwoButton.Click += new System.EventHandler(this.formatTwoButton_Click);
            // 
            // formatThreeButton
            // 
            this.formatThreeButton.Location = new System.Drawing.Point(385, 389);
            this.formatThreeButton.Name = "formatThreeButton";
            this.formatThreeButton.Size = new System.Drawing.Size(150, 50);
            this.formatThreeButton.TabIndex = 11;
            this.formatThreeButton.Text = "Format 3";
            this.formatThreeButton.UseVisualStyleBackColor = true;
            this.formatThreeButton.Click += new System.EventHandler(this.formatThreeButton_Click);
            // 
            // formatFourButton
            // 
            this.formatFourButton.Location = new System.Drawing.Point(563, 389);
            this.formatFourButton.Name = "formatFourButton";
            this.formatFourButton.Size = new System.Drawing.Size(150, 50);
            this.formatFourButton.TabIndex = 12;
            this.formatFourButton.Text = "Format 4";
            this.formatFourButton.UseVisualStyleBackColor = true;
            this.formatFourButton.Click += new System.EventHandler(this.formatFourButton_Click);
            // 
            // formatFiveButton
            // 
            this.formatFiveButton.Location = new System.Drawing.Point(184, 464);
            this.formatFiveButton.Name = "formatFiveButton";
            this.formatFiveButton.Size = new System.Drawing.Size(150, 50);
            this.formatFiveButton.TabIndex = 13;
            this.formatFiveButton.Text = "Format 5";
            this.formatFiveButton.UseVisualStyleBackColor = true;
            this.formatFiveButton.Click += new System.EventHandler(this.formatFiveButton_Click);
            // 
            // formatSixButton
            // 
            this.formatSixButton.Location = new System.Drawing.Point(412, 464);
            this.formatSixButton.Name = "formatSixButton";
            this.formatSixButton.Size = new System.Drawing.Size(150, 50);
            this.formatSixButton.TabIndex = 14;
            this.formatSixButton.Text = "Format 6";
            this.formatSixButton.UseVisualStyleBackColor = true;
            this.formatSixButton.Click += new System.EventHandler(this.formatSixButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 553);
            this.Controls.Add(this.formatSixButton);
            this.Controls.Add(this.formatFiveButton);
            this.Controls.Add(this.formatFourButton);
            this.Controls.Add(this.formatThreeButton);
            this.Controls.Add(this.formatTwoButton);
            this.Controls.Add(this.formatOneButton);
            this.Controls.Add(this.nameOutputLabel);
            this.Controls.Add(this.preferredTitleTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.preferredTitleLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label preferredTitleLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox preferredTitleTextBox;
        private System.Windows.Forms.Label nameOutputLabel;
        private System.Windows.Forms.Button formatOneButton;
        private System.Windows.Forms.Button formatTwoButton;
        private System.Windows.Forms.Button formatThreeButton;
        private System.Windows.Forms.Button formatFourButton;
        private System.Windows.Forms.Button formatFiveButton;
        private System.Windows.Forms.Button formatSixButton;
    }
}

