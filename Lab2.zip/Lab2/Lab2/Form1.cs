﻿// ID: B8994
// Lab 2
// Due: 5 February 2017
// CIS 199-02

// Description: This program asks the user for their first, middle, and
// last names, as well as their preferred title. Upon clicking any one
// of six buttons, the names and/or title are presented in the label in
// various orders. This is accomplished through the use of local string
// variables, one within each event.

// A note to those completing peer evaluation: You might have to click
// the expand button to the left of each event handler to see all of my
// code for each button individually.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void formatOneButton_Click(object sender, EventArgs e)
        {
            string outputOne;// Declaring the variable used by formatOneButton

            // Preferred title, First Name, Middle Name, Last Name
            outputOne = preferredTitleTextBox.Text + " " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text + " " +
                lastNameTextBox.Text;

            // Display "outputOne" in nameOutputLabel
            nameOutputLabel.Text = outputOne;
        }

        private void formatTwoButton_Click(object sender, EventArgs e)
        {
            string outputTwo;// Declaring the variable used by formatTwoButton

            // First Name, Middle Name, Last Name
            outputTwo = firstNameTextBox.Text + " " +
                middleNameTextBox.Text + " " +
                lastNameTextBox.Text;

            // Display "outputTwo" in nameOutputLabel
            nameOutputLabel.Text = outputTwo;
        }

        private void formatThreeButton_Click(object sender, EventArgs e)
        {
            string outputThree;// Declaring the variable used by formatThreeButton

            // First Name Last Name
            outputThree = firstNameTextBox.Text + " " +
                lastNameTextBox.Text;

            // Display "outputThree" in nameOutputLabel
            nameOutputLabel.Text = outputThree;
        }

        private void formatFourButton_Click(object sender, EventArgs e)
        {
            string outputFour;// Declaring the variable used by formatFourButton

            // Last Name, First Name Middle Name, Preferred Title
            outputFour = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text + ", " +
                preferredTitleTextBox.Text;

            // Display "outputFour" in nameOutputLabel
            nameOutputLabel.Text = outputFour;
        }

        private void formatFiveButton_Click(object sender, EventArgs e)
        {
            string outputFive;// Declaring the variable used by formatFiveButton

            // Last Name, First Name Middle Name
            outputFive = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text + " " +
                middleNameTextBox.Text;

            // Display "outputFive" in nameOutputLabel
            nameOutputLabel.Text = outputFive;
        }

        private void formatSixButton_Click(object sender, EventArgs e)
        {
            string outputSix;// Declaring the variable used by formatSixButton

            // Last Name, First Name
            outputSix = lastNameTextBox.Text + ", " +
                firstNameTextBox.Text;

            // Display "outputSix" in nameOutputLabel
            nameOutputLabel.Text = outputSix;
        }
    }
}
