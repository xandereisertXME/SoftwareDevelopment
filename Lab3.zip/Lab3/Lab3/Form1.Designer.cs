﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterPriceLabel = new System.Windows.Forms.Label();
            this.tipPercent1Label = new System.Windows.Forms.Label();
            this.tipPercent2Label = new System.Windows.Forms.Label();
            this.tipPercent3Label = new System.Windows.Forms.Label();
            this.mealPriceTextbox = new System.Windows.Forms.TextBox();
            this.tip1OutputLabel = new System.Windows.Forms.Label();
            this.tip2OutputLabel = new System.Windows.Forms.Label();
            this.tip3OutputLabel = new System.Windows.Forms.Label();
            this.calculateTipButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enterPriceLabel
            // 
            this.enterPriceLabel.AutoSize = true;
            this.enterPriceLabel.Location = new System.Drawing.Point(102, 132);
            this.enterPriceLabel.Name = "enterPriceLabel";
            this.enterPriceLabel.Size = new System.Drawing.Size(285, 25);
            this.enterPriceLabel.TabIndex = 0;
            this.enterPriceLabel.Text = "Enter the Price of your Meal:";
            // 
            // tipPercent1Label
            // 
            this.tipPercent1Label.AutoSize = true;
            this.tipPercent1Label.Location = new System.Drawing.Point(326, 199);
            this.tipPercent1Label.Name = "tipPercent1Label";
            this.tipPercent1Label.Size = new System.Drawing.Size(0, 25);
            this.tipPercent1Label.TabIndex = 1;
            // 
            // tipPercent2Label
            // 
            this.tipPercent2Label.AutoSize = true;
            this.tipPercent2Label.Location = new System.Drawing.Point(326, 267);
            this.tipPercent2Label.Name = "tipPercent2Label";
            this.tipPercent2Label.Size = new System.Drawing.Size(0, 25);
            this.tipPercent2Label.TabIndex = 2;
            // 
            // tipPercent3Label
            // 
            this.tipPercent3Label.AutoSize = true;
            this.tipPercent3Label.Location = new System.Drawing.Point(326, 330);
            this.tipPercent3Label.Name = "tipPercent3Label";
            this.tipPercent3Label.Size = new System.Drawing.Size(0, 25);
            this.tipPercent3Label.TabIndex = 3;
            // 
            // mealPriceTextbox
            // 
            this.mealPriceTextbox.Location = new System.Drawing.Point(421, 129);
            this.mealPriceTextbox.Name = "mealPriceTextbox";
            this.mealPriceTextbox.Size = new System.Drawing.Size(250, 31);
            this.mealPriceTextbox.TabIndex = 4;
            // 
            // tip1OutputLabel
            // 
            this.tip1OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tip1OutputLabel.Location = new System.Drawing.Point(421, 199);
            this.tip1OutputLabel.Name = "tip1OutputLabel";
            this.tip1OutputLabel.Size = new System.Drawing.Size(250, 31);
            this.tip1OutputLabel.TabIndex = 5;
            // 
            // tip2OutputLabel
            // 
            this.tip2OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tip2OutputLabel.Location = new System.Drawing.Point(421, 266);
            this.tip2OutputLabel.Name = "tip2OutputLabel";
            this.tip2OutputLabel.Size = new System.Drawing.Size(250, 31);
            this.tip2OutputLabel.TabIndex = 6;
            // 
            // tip3OutputLabel
            // 
            this.tip3OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tip3OutputLabel.Location = new System.Drawing.Point(421, 329);
            this.tip3OutputLabel.Name = "tip3OutputLabel";
            this.tip3OutputLabel.Size = new System.Drawing.Size(250, 31);
            this.tip3OutputLabel.TabIndex = 7;
            // 
            // calculateTipButton
            // 
            this.calculateTipButton.Location = new System.Drawing.Point(272, 446);
            this.calculateTipButton.Name = "calculateTipButton";
            this.calculateTipButton.Size = new System.Drawing.Size(212, 78);
            this.calculateTipButton.TabIndex = 8;
            this.calculateTipButton.Text = "Calculate Tip";
            this.calculateTipButton.UseVisualStyleBackColor = true;
            this.calculateTipButton.Click += new System.EventHandler(this.calculateTipButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateTipButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 600);
            this.Controls.Add(this.calculateTipButton);
            this.Controls.Add(this.tip3OutputLabel);
            this.Controls.Add(this.tip2OutputLabel);
            this.Controls.Add(this.tip1OutputLabel);
            this.Controls.Add(this.mealPriceTextbox);
            this.Controls.Add(this.tipPercent3Label);
            this.Controls.Add(this.tipPercent2Label);
            this.Controls.Add(this.tipPercent1Label);
            this.Controls.Add(this.enterPriceLabel);
            this.Name = "Form1";
            this.Text = "Lab 3";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterPriceLabel;
        private System.Windows.Forms.Label tipPercent1Label;
        private System.Windows.Forms.Label tipPercent2Label;
        private System.Windows.Forms.Label tipPercent3Label;
        private System.Windows.Forms.TextBox mealPriceTextbox;
        private System.Windows.Forms.Label tip1OutputLabel;
        private System.Windows.Forms.Label tip2OutputLabel;
        private System.Windows.Forms.Label tip3OutputLabel;
        private System.Windows.Forms.Button calculateTipButton;
    }
}

