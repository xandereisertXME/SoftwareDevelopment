﻿// ID: B8994
// Lab 3
// Due: 12 February 2017
// CIS 199-02

// Description: This program calculates the amount that should be added as a tip
// on a restaurant ticket. It is an example of declaring constants and using
// their values within the program, as is seen with the specified tip amounts.
// The program calculates a 15% tip, an 18% tip, and a 20% tip, but the three tip
// amounts can be changed in the declaration of conatants on lines 28-30.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {

        // Declaring the small, medium, and large tip rates, respectively
        const decimal SMALL_TIP = .15m;  // 15% tip
        const decimal MEDIUM_TIP = .18m; // 18% tip
        const decimal LARGE_TIP = .20m;  // 20% tip

        public Form1()
        {
            InitializeComponent();
            
        }

        // Clicking the calculate button calculates the tip amount in dollars
        // for the small, medium, and large tips all at the same time
        private void calculateTipButton_Click(object sender, EventArgs e)
        {
            
            decimal smallTip = 0m;  // Small tip placeholder local vairble
            decimal mediumTip = 0m; // Medium tip placeholder local variable
            decimal largeTip = 0m;  // Large tip placeholder local variable

            // Small tip label output
            smallTip = SMALL_TIP * decimal.Parse(mealPriceTextbox.Text); // Multiply cost of dinner by each tip value
            // Display small tip amount on tip1OutputLabel in currency format
            tip1OutputLabel.Text = smallTip.ToString("c");

            // Medium tip label output
            mediumTip = MEDIUM_TIP * decimal.Parse(mealPriceTextbox.Text); // Multiply cost of dinner by each tip value
            // Display medium tip amount on tip2OutputLabel in currency format
            tip2OutputLabel.Text = mediumTip.ToString("c");

            //Large tip label output
            largeTip = LARGE_TIP * decimal.Parse(mealPriceTextbox.Text); // Multiply cost of dinner by each tip value
            // Display large tip amount on tip3OutputLabel in currency format
            tip3OutputLabel.Text = largeTip.ToString("c");
        }

        // Changes the percent labels to the ToString values of the constants 
        // in the percentage format
        private void Form1_Load(object sender, EventArgs e)
        {
            tipPercent1Label.Text = SMALL_TIP.ToString("p0") + ":";
            tipPercent2Label.Text = MEDIUM_TIP.ToString("p0") + ":";
            tipPercent3Label.Text = LARGE_TIP.ToString("p0") + ":";
        }
    }
}
