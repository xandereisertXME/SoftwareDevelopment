﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLabel = new System.Windows.Forms.Label();
            this.admissionTestLabel = new System.Windows.Forms.Label();
            this.nullAcceptedLabel = new System.Windows.Forms.Label();
            this.nullRejectedLabel = new System.Windows.Forms.Label();
            this.acceptedLabel = new System.Windows.Forms.Label();
            this.rejectedLabel = new System.Windows.Forms.Label();
            this.gpaTextbox = new System.Windows.Forms.TextBox();
            this.admissionTextbox = new System.Windows.Forms.TextBox();
            this.checkElegibilityButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gpaLabel
            // 
            this.gpaLabel.AutoSize = true;
            this.gpaLabel.Location = new System.Drawing.Point(223, 60);
            this.gpaLabel.Name = "gpaLabel";
            this.gpaLabel.Size = new System.Drawing.Size(62, 25);
            this.gpaLabel.TabIndex = 0;
            this.gpaLabel.Text = "GPA:";
            // 
            // admissionTestLabel
            // 
            this.admissionTestLabel.AutoSize = true;
            this.admissionTestLabel.Location = new System.Drawing.Point(58, 140);
            this.admissionTestLabel.Name = "admissionTestLabel";
            this.admissionTestLabel.Size = new System.Drawing.Size(227, 25);
            this.admissionTestLabel.TabIndex = 1;
            this.admissionTestLabel.Text = "Admission Test Score:";
            // 
            // nullAcceptedLabel
            // 
            this.nullAcceptedLabel.AutoSize = true;
            this.nullAcceptedLabel.Location = new System.Drawing.Point(53, 268);
            this.nullAcceptedLabel.Name = "nullAcceptedLabel";
            this.nullAcceptedLabel.Size = new System.Drawing.Size(108, 25);
            this.nullAcceptedLabel.TabIndex = 2;
            this.nullAcceptedLabel.Text = "Accepted:";
            // 
            // nullRejectedLabel
            // 
            this.nullRejectedLabel.AutoSize = true;
            this.nullRejectedLabel.Location = new System.Drawing.Point(58, 322);
            this.nullRejectedLabel.Name = "nullRejectedLabel";
            this.nullRejectedLabel.Size = new System.Drawing.Size(103, 25);
            this.nullRejectedLabel.TabIndex = 3;
            this.nullRejectedLabel.Text = "Rejected:";
            // 
            // acceptedLabel
            // 
            this.acceptedLabel.AutoSize = true;
            this.acceptedLabel.Location = new System.Drawing.Point(186, 268);
            this.acceptedLabel.Name = "acceptedLabel";
            this.acceptedLabel.Size = new System.Drawing.Size(24, 25);
            this.acceptedLabel.TabIndex = 4;
            this.acceptedLabel.Text = "0";
            // 
            // rejectedLabel
            // 
            this.rejectedLabel.AutoSize = true;
            this.rejectedLabel.Location = new System.Drawing.Point(186, 322);
            this.rejectedLabel.Name = "rejectedLabel";
            this.rejectedLabel.Size = new System.Drawing.Size(24, 25);
            this.rejectedLabel.TabIndex = 5;
            this.rejectedLabel.Text = "0";
            // 
            // gpaTextbox
            // 
            this.gpaTextbox.Location = new System.Drawing.Point(333, 57);
            this.gpaTextbox.Name = "gpaTextbox";
            this.gpaTextbox.Size = new System.Drawing.Size(200, 31);
            this.gpaTextbox.TabIndex = 6;
            // 
            // admissionTextbox
            // 
            this.admissionTextbox.Location = new System.Drawing.Point(333, 137);
            this.admissionTextbox.Name = "admissionTextbox";
            this.admissionTextbox.Size = new System.Drawing.Size(200, 31);
            this.admissionTextbox.TabIndex = 7;
            // 
            // checkElegibilityButton
            // 
            this.checkElegibilityButton.Location = new System.Drawing.Point(344, 278);
            this.checkElegibilityButton.Name = "checkElegibilityButton";
            this.checkElegibilityButton.Size = new System.Drawing.Size(179, 69);
            this.checkElegibilityButton.TabIndex = 8;
            this.checkElegibilityButton.Text = "Check Elegibility";
            this.checkElegibilityButton.UseVisualStyleBackColor = true;
            this.checkElegibilityButton.Click += new System.EventHandler(this.checkElegibilityButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.checkElegibilityButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 393);
            this.Controls.Add(this.checkElegibilityButton);
            this.Controls.Add(this.admissionTextbox);
            this.Controls.Add(this.gpaTextbox);
            this.Controls.Add(this.rejectedLabel);
            this.Controls.Add(this.acceptedLabel);
            this.Controls.Add(this.nullRejectedLabel);
            this.Controls.Add(this.nullAcceptedLabel);
            this.Controls.Add(this.admissionTestLabel);
            this.Controls.Add(this.gpaLabel);
            this.Name = "Form1";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLabel;
        private System.Windows.Forms.Label admissionTestLabel;
        private System.Windows.Forms.Label nullAcceptedLabel;
        private System.Windows.Forms.Label nullRejectedLabel;
        private System.Windows.Forms.Label acceptedLabel;
        private System.Windows.Forms.Label rejectedLabel;
        private System.Windows.Forms.TextBox gpaTextbox;
        private System.Windows.Forms.TextBox admissionTextbox;
        private System.Windows.Forms.Button checkElegibilityButton;
    }
}

