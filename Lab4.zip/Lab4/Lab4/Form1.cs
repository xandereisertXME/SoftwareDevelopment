﻿// ID: B8994
// Lab 4
// Due: 19 February 2017
// CIS 199-02

// Description: This program checks a student's elegibility based on either their GPA or
// their admission test score, and keeps a running total of accepted and rejected students
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {

        private ushort totalAccepted = 0; // Private field variable for total accepted
        private ushort totalRejected = 0; // Private field variable for total rejected

        public Form1()
        {
            InitializeComponent();
        }

        private void checkElegibilityButton_Click(object sender, EventArgs e)
        {
            float gpa;         // GPA variable for parsing
            ushort admission;  // Admission test score variable for parsing

            // Data validation by parsing
            if (float.TryParse(gpaTextbox.Text, out gpa))
            {
                if (ushort.TryParse(admissionTextbox.Text, out admission))
                {

                    // Assigning the valid data formats to the variables gpa and admission
                    gpa = float.Parse(gpaTextbox.Text);
                    admission = ushort.Parse(admissionTextbox.Text);

                    // Test for whether GPA is greater than or equal to 3.0 and test score is greater
                    // than or equal to 60, program displays acceptance message and adds to acceptance
                    // counter
                    if (gpa >= 3.0 && admission >= 60)
                    {
                        MessageBox.Show("Accepted");
                        totalAccepted += 1;
                        acceptedLabel.Text = totalAccepted.ToString("n0");
                    }

                    // Secondary test for whether test score is above 80, program displays acceptance
                    // message and adds to acceptance counter
                    else if (admission >= 80)
                    {
                        MessageBox.Show("Accepted");
                        totalAccepted += 1;
                        acceptedLabel.Text = totalAccepted.ToString("n0");
                    }

                    // Program displays rejection message and adds to rejection counter
                    else
                    {
                        MessageBox.Show("Rejected");
                        totalRejected += 1;
                        rejectedLabel.Text = totalRejected.ToString("n0");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid test score greater than or equal to 0");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid GPA");
            }
        }
    }
}


