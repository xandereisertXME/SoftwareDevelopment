﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoopGroupBox = new System.Windows.Forms.GroupBox();
            this.whileRadio = new System.Windows.Forms.RadioButton();
            this.forRadio = new System.Windows.Forms.RadioButton();
            this.doWhileRadio = new System.Windows.Forms.RadioButton();
            this.fromLabel = new System.Windows.Forms.Label();
            this.toLabel = new System.Windows.Forms.Label();
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.toTextBox = new System.Windows.Forms.TextBox();
            this.outputListBox = new System.Windows.Forms.ListBox();
            this.runButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.LoopGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoopGroupBox
            // 
            this.LoopGroupBox.Controls.Add(this.doWhileRadio);
            this.LoopGroupBox.Controls.Add(this.forRadio);
            this.LoopGroupBox.Controls.Add(this.whileRadio);
            this.LoopGroupBox.Location = new System.Drawing.Point(35, 178);
            this.LoopGroupBox.Name = "LoopGroupBox";
            this.LoopGroupBox.Size = new System.Drawing.Size(200, 184);
            this.LoopGroupBox.TabIndex = 0;
            this.LoopGroupBox.TabStop = false;
            this.LoopGroupBox.Text = "Loop Using:";
            // 
            // whileRadio
            // 
            this.whileRadio.AutoSize = true;
            this.whileRadio.Location = new System.Drawing.Point(11, 41);
            this.whileRadio.Name = "whileRadio";
            this.whileRadio.Size = new System.Drawing.Size(92, 29);
            this.whileRadio.TabIndex = 0;
            this.whileRadio.TabStop = true;
            this.whileRadio.Text = "while";
            this.whileRadio.UseVisualStyleBackColor = true;
            // 
            // forRadio
            // 
            this.forRadio.AutoSize = true;
            this.forRadio.Location = new System.Drawing.Point(11, 88);
            this.forRadio.Name = "forRadio";
            this.forRadio.Size = new System.Drawing.Size(68, 29);
            this.forRadio.TabIndex = 1;
            this.forRadio.TabStop = true;
            this.forRadio.Text = "for";
            this.forRadio.UseVisualStyleBackColor = true;
            // 
            // doWhileRadio
            // 
            this.doWhileRadio.AutoSize = true;
            this.doWhileRadio.Location = new System.Drawing.Point(11, 137);
            this.doWhileRadio.Name = "doWhileRadio";
            this.doWhileRadio.Size = new System.Drawing.Size(122, 29);
            this.doWhileRadio.TabIndex = 2;
            this.doWhileRadio.TabStop = true;
            this.doWhileRadio.Text = "do while";
            this.doWhileRadio.UseVisualStyleBackColor = true;
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(30, 31);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(67, 25);
            this.fromLabel.TabIndex = 3;
            this.fromLabel.Text = "From:";
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.Location = new System.Drawing.Point(30, 103);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(43, 25);
            this.toLabel.TabIndex = 4;
            this.toLabel.Text = "To:";
            // 
            // fromTextBox
            // 
            this.fromTextBox.Location = new System.Drawing.Point(35, 59);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(200, 31);
            this.fromTextBox.TabIndex = 5;
            // 
            // toTextBox
            // 
            this.toTextBox.Location = new System.Drawing.Point(35, 131);
            this.toTextBox.Name = "toTextBox";
            this.toTextBox.Size = new System.Drawing.Size(200, 31);
            this.toTextBox.TabIndex = 6;
            // 
            // outputListBox
            // 
            this.outputListBox.FormattingEnabled = true;
            this.outputListBox.ItemHeight = 25;
            this.outputListBox.Location = new System.Drawing.Point(294, 31);
            this.outputListBox.Name = "outputListBox";
            this.outputListBox.Size = new System.Drawing.Size(194, 429);
            this.outputListBox.TabIndex = 7;
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(35, 378);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(200, 38);
            this.runButton.TabIndex = 8;
            this.runButton.Text = "Run Loop";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearButton.Location = new System.Drawing.Point(35, 422);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(200, 38);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear List";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.runButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearButton;
            this.ClientSize = new System.Drawing.Size(516, 487);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.outputListBox);
            this.Controls.Add(this.toTextBox);
            this.Controls.Add(this.fromTextBox);
            this.Controls.Add(this.toLabel);
            this.Controls.Add(this.fromLabel);
            this.Controls.Add(this.LoopGroupBox);
            this.Name = "Form1";
            this.Text = "Lab 5";
            this.LoopGroupBox.ResumeLayout(false);
            this.LoopGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox LoopGroupBox;
        private System.Windows.Forms.RadioButton doWhileRadio;
        private System.Windows.Forms.RadioButton forRadio;
        private System.Windows.Forms.RadioButton whileRadio;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.TextBox toTextBox;
        private System.Windows.Forms.ListBox outputListBox;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Button clearButton;
    }
}

