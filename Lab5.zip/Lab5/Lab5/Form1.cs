﻿// ID: B8994
// Lab 4
// Due: 5 March 2017
// CIS 199-02

// Description: This program allows the user to input a starting point and an ending point
// for counter-controlled repetition in the form of three different optional loops: a while
// loop, a for loop, and a do-while loop.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void runButton_Click(object sender, EventArgs e)
        {
            int from;  // This variable will hold the value input by the user in the "From" textbox
            int to;    // This variable will hold the value input by the user in the "To" textbox

            // TryParse method for the "From" textbox
            if (int.TryParse(fromTextBox.Text, out from))
                {
                // TryPase method for the "To" textbox
                if (int.TryParse(toTextBox.Text, out to))
                    {
                    if (whileRadio.Checked)
                        {
                        // While loop section
                        while (from <= to)
                            {
                            // Add to the ListBox
                            outputListBox.Items.Add(from.ToString("n0"));
                            // Increment "From" value
                            from = from + 1;
                            }
                        }
                    else if (forRadio.Checked)
                        {
                        // For loop section
                        for (from = from; from <= to; from++)
                            {
                            // Add to the ListBox
                            outputListBox.Items.Add(from.ToString("n0"));
                            }
                        }
                    else
                        {
                        // Do while loop section
                        do
                            {
                            outputListBox.Items.Add(from.ToString("n0"));
                            ++from;
                            } while (from <= to);
                        }
                    }
                    else
                        {
                            // Error message for failure of TryParse on the "To" textbox
                            MessageBox.Show("Please enter a valid 'To' value");
                        }
                }
                else
                    {
                        // Error message for failure of TryParse on the "From" textbox
                        MessageBox.Show("Please enter a valid 'From' value");
                    }
            }
        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the ListBox of all values
            outputListBox.Items.Clear();
        }
    }
}


