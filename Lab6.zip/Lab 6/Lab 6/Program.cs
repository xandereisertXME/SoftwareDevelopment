﻿// ID: B8994
// Lab 6
// Due: 12 March 2017
// CIS 199-02

// Description: This program creates four star patterns using different for loops.

// NOTE: Because I used the Console.ReadLine command at the very end of the program, it is
// not necessary to press Control + F5 to view the code output. Just press start.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10; // Maximum number of rows needed to draw any of the four star shapes
            // row = number of lines total
            // space = number of spaces in a single line
            // star = number of stars in a single line

            Console.WriteLine();
            Console.WriteLine("Pattern A");
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Pattern B");
            Console.WriteLine();
            for (int row = 10; row + MAX_ROWS >= MAX_ROWS; row--)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Pattern C");
            Console.WriteLine();
            for (int row = 10; row + MAX_ROWS >= MAX_ROWS; row--)
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)
                    Console.Write(" ");
                {
                    for (int star = 1; star <= row; star++)
                        Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Pattern D");
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)
                    Console.Write(" ");
                {
                    for (int star = 1; star <= row; star++)
                        Console.Write("*");
                }
                Console.WriteLine();
            }
        Console.ReadLine();
        }
    }
}
