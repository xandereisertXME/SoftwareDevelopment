﻿namespace Lab7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValueLabel = new System.Windows.Forms.Label();
            this.annInterestLabel = new System.Windows.Forms.Label();
            this.yearsLabel = new System.Windows.Forms.Label();
            this.presValueLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.futureTextBox = new System.Windows.Forms.TextBox();
            this.interestTextBox = new System.Windows.Forms.TextBox();
            this.yearsTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // futureValueLabel
            // 
            this.futureValueLabel.AutoSize = true;
            this.futureValueLabel.Location = new System.Drawing.Point(72, 55);
            this.futureValueLabel.Name = "futureValueLabel";
            this.futureValueLabel.Size = new System.Drawing.Size(141, 25);
            this.futureValueLabel.TabIndex = 0;
            this.futureValueLabel.Text = "Future Value:";
            // 
            // annInterestLabel
            // 
            this.annInterestLabel.AutoSize = true;
            this.annInterestLabel.Location = new System.Drawing.Point(72, 125);
            this.annInterestLabel.Name = "annInterestLabel";
            this.annInterestLabel.Size = new System.Drawing.Size(213, 25);
            this.annInterestLabel.TabIndex = 1;
            this.annInterestLabel.Text = "Annual Interest Rate:";
            // 
            // yearsLabel
            // 
            this.yearsLabel.AutoSize = true;
            this.yearsLabel.Location = new System.Drawing.Point(72, 195);
            this.yearsLabel.Name = "yearsLabel";
            this.yearsLabel.Size = new System.Drawing.Size(138, 25);
            this.yearsLabel.TabIndex = 2;
            this.yearsLabel.Text = "No. of Years:";
            // 
            // presValueLabel
            // 
            this.presValueLabel.AutoSize = true;
            this.presValueLabel.Location = new System.Drawing.Point(72, 265);
            this.presValueLabel.Name = "presValueLabel";
            this.presValueLabel.Size = new System.Drawing.Size(153, 25);
            this.presValueLabel.TabIndex = 3;
            this.presValueLabel.Text = "Present Value:";
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLabel.Location = new System.Drawing.Point(394, 264);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(200, 31);
            this.outputLabel.TabIndex = 4;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(233, 345);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(187, 53);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // futureTextBox
            // 
            this.futureTextBox.Location = new System.Drawing.Point(394, 55);
            this.futureTextBox.Name = "futureTextBox";
            this.futureTextBox.Size = new System.Drawing.Size(200, 31);
            this.futureTextBox.TabIndex = 6;
            // 
            // interestTextBox
            // 
            this.interestTextBox.Location = new System.Drawing.Point(394, 125);
            this.interestTextBox.Name = "interestTextBox";
            this.interestTextBox.Size = new System.Drawing.Size(200, 31);
            this.interestTextBox.TabIndex = 7;
            // 
            // yearsTextBox
            // 
            this.yearsTextBox.Location = new System.Drawing.Point(394, 195);
            this.yearsTextBox.Name = "yearsTextBox";
            this.yearsTextBox.Size = new System.Drawing.Size(200, 31);
            this.yearsTextBox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 429);
            this.Controls.Add(this.yearsTextBox);
            this.Controls.Add(this.interestTextBox);
            this.Controls.Add(this.futureTextBox);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.presValueLabel);
            this.Controls.Add(this.yearsLabel);
            this.Controls.Add(this.annInterestLabel);
            this.Controls.Add(this.futureValueLabel);
            this.Name = "Form1";
            this.Text = "Lab 7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValueLabel;
        private System.Windows.Forms.Label annInterestLabel;
        private System.Windows.Forms.Label yearsLabel;
        private System.Windows.Forms.Label presValueLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.TextBox futureTextBox;
        private System.Windows.Forms.TextBox interestTextBox;
        private System.Windows.Forms.TextBox yearsTextBox;
    }
}

