﻿// ID: B8994
// Lab 7
// Due: 26 March 2017
// CIS 199-02

// Description: This program passes three variables to a method that performs the
// present-value formula and outputs the result.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Preconditions: future, rate, years > 0
        // Postconditions: The method will perform the present-value formula to determine
        // the necessary amount needed to deposit into the bank if one wants to achieve a
        // certain monetary value, "future", at a certain interest rate, "rate", after any 
        // number of years, "years"
        public double PresentValue(double future, double rate, int years)
        {
            return future / Math.Pow(1 + rate, years);
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variables to represent desired future value and annual interest rate, as well
            // as the "present" value which will be assigned the result of the calculation
            double future, rate, present;
            // Also an int variable to represent number of years
            int years;

            // Performing all three TryParse checks
            if (double.TryParse(futureTextBox.Text, out future))
            {
                if (double.TryParse(interestTextBox.Text, out rate))
                {
                    if (int.TryParse(yearsTextBox.Text, out years))
                    {
                        // Performing the pass to the method
                        // Carrying out the present-value formula
                        present = PresentValue(future, rate, years);

                        // Output to Label
                        outputLabel.Text = present.ToString("c2");

                    }
                    else
                    {
                        MessageBox.Show("Enter a valid number of years");
                    }
                }
                else
                {
                    MessageBox.Show("Enter a valid interest rate");
                }
            }
            else
            {
                MessageBox.Show("Enter a valid future amount");
            }
        }
    }
}
