﻿namespace Lab8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthLabel = new System.Windows.Forms.Label();
            this.monthTextBox = new System.Windows.Forms.TextBox();
            this.langGroupBox1 = new System.Windows.Forms.GroupBox();
            this.italianRadio = new System.Windows.Forms.RadioButton();
            this.spanishRadio = new System.Windows.Forms.RadioButton();
            this.englishRadio = new System.Windows.Forms.RadioButton();
            this.outputLabel = new System.Windows.Forms.Label();
            this.lookupLabel = new System.Windows.Forms.Button();
            this.langGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthLabel
            // 
            this.monthLabel.AutoSize = true;
            this.monthLabel.Location = new System.Drawing.Point(29, 63);
            this.monthLabel.Name = "monthLabel";
            this.monthLabel.Size = new System.Drawing.Size(96, 25);
            this.monthLabel.TabIndex = 0;
            this.monthLabel.Text = "Month #:";
            // 
            // monthTextBox
            // 
            this.monthTextBox.Location = new System.Drawing.Point(149, 60);
            this.monthTextBox.Name = "monthTextBox";
            this.monthTextBox.Size = new System.Drawing.Size(200, 31);
            this.monthTextBox.TabIndex = 1;
            // 
            // langGroupBox1
            // 
            this.langGroupBox1.Controls.Add(this.italianRadio);
            this.langGroupBox1.Controls.Add(this.spanishRadio);
            this.langGroupBox1.Controls.Add(this.englishRadio);
            this.langGroupBox1.Location = new System.Drawing.Point(34, 125);
            this.langGroupBox1.Name = "langGroupBox1";
            this.langGroupBox1.Size = new System.Drawing.Size(315, 154);
            this.langGroupBox1.TabIndex = 2;
            this.langGroupBox1.TabStop = false;
            this.langGroupBox1.Text = "Choose Language:";
            // 
            // italianRadio
            // 
            this.italianRadio.AutoSize = true;
            this.italianRadio.Location = new System.Drawing.Point(11, 110);
            this.italianRadio.Name = "italianRadio";
            this.italianRadio.Size = new System.Drawing.Size(100, 29);
            this.italianRadio.TabIndex = 2;
            this.italianRadio.TabStop = true;
            this.italianRadio.Text = "Italian";
            this.italianRadio.UseVisualStyleBackColor = true;
            // 
            // spanishRadio
            // 
            this.spanishRadio.AutoSize = true;
            this.spanishRadio.Location = new System.Drawing.Point(11, 75);
            this.spanishRadio.Name = "spanishRadio";
            this.spanishRadio.Size = new System.Drawing.Size(121, 29);
            this.spanishRadio.TabIndex = 1;
            this.spanishRadio.TabStop = true;
            this.spanishRadio.Text = "Spanish";
            this.spanishRadio.UseVisualStyleBackColor = true;
            // 
            // englishRadio
            // 
            this.englishRadio.AutoSize = true;
            this.englishRadio.Location = new System.Drawing.Point(11, 40);
            this.englishRadio.Name = "englishRadio";
            this.englishRadio.Size = new System.Drawing.Size(114, 29);
            this.englishRadio.TabIndex = 0;
            this.englishRadio.TabStop = true;
            this.englishRadio.Text = "English";
            this.englishRadio.UseVisualStyleBackColor = true;
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(34, 305);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(315, 56);
            this.outputLabel.TabIndex = 3;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lookupLabel
            // 
            this.lookupLabel.Location = new System.Drawing.Point(95, 388);
            this.lookupLabel.Name = "lookupLabel";
            this.lookupLabel.Size = new System.Drawing.Size(179, 54);
            this.lookupLabel.TabIndex = 4;
            this.lookupLabel.Text = "Look Up";
            this.lookupLabel.UseVisualStyleBackColor = true;
            this.lookupLabel.Click += new System.EventHandler(this.lookupLabel_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.lookupLabel;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 490);
            this.Controls.Add(this.lookupLabel);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.langGroupBox1);
            this.Controls.Add(this.monthTextBox);
            this.Controls.Add(this.monthLabel);
            this.Name = "Form1";
            this.Text = "Lab 8";
            this.langGroupBox1.ResumeLayout(false);
            this.langGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label monthLabel;
        private System.Windows.Forms.TextBox monthTextBox;
        private System.Windows.Forms.GroupBox langGroupBox1;
        private System.Windows.Forms.RadioButton italianRadio;
        private System.Windows.Forms.RadioButton spanishRadio;
        private System.Windows.Forms.RadioButton englishRadio;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button lookupLabel;
    }
}

