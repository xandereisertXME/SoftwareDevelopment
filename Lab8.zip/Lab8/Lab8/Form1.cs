﻿// ID: B8994
// Lab 8
// Due: 2 April 2017
// CIS 199-02

// Description: This program uses three methods to call the names of any month in
// one of three languages, selected by the user through use of radio buttons.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Preconditions: month value <= 12
        // Postconditions: method will return the name of the nth month in English
        public string englishMonth(int month)
        {
            month = month - 1; // Accounting for index starting at 0 instead of 1
            string[] englishNames = { "January", "February", "March", "April", "May", "June", "July",
                                       "August", "September", "October", "November", "December"};
            return englishNames[month].ToString();
        }

        // Preconditions: month value <= 12
        // Postconditions: method will return the name of the nth month in Spanish
        public string spanishMonth(int month)
        {
            month = month - 1; // Accounting for index starting at 0 instead of 1
            string[] spanishNames = { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
                                       "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
            return spanishNames[month].ToString();
        }

        // Preconditions: month value <= 12
        // Postconditions: method will return the name of the nth month in Italian
        public string italianMonth(int month)
        {
            month = month - 1; // Accounting for index starting at 0 instead of 1
            string[] italianNames = { "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio",
                                       "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"};
            return italianNames[month].ToString();
        }

        private void lookupLabel_Click(object sender, EventArgs e)
        {
            int month;  // Used for storing the month value 
            if (int.TryParse(monthTextBox.Text, out month) && month <= 12 && month > 0)
                if (englishRadio.Checked)
                    outputLabel.Text = englishMonth(month);
                else if (spanishRadio.Checked)
                    outputLabel.Text = spanishMonth(month);
                else if (italianRadio.Checked)
                    outputLabel.Text = italianMonth(month);
                else
                    MessageBox.Show("Please select a language");
            else
                MessageBox.Show("Please enter a valid value for month (1 - 12)");
        }
    }
}

