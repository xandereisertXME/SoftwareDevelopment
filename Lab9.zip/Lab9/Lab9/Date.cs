﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    public class Date
    {
        private int _month; // 1 to 12
        private int _day;   // 1 to 31
        private int _year;  // >= 0

        // Precondition:  0 < m <= 12
        //                0 < d <= 31
        //                0 <= y
        // Postcondition: The Date object has been initialized with the specified
        //                month, day and year
        public Date(int m = 1, int d = 1, int y = 2000)
        {
            //Month = m; // set the Month property
            //Day = d; // set the Day property
            //Year = y; // set the Year property

            SetDate(m, d, y);
        }

        // Precondition:  0 < m <= 12
        //                0 < d <= 31
        //                0 <= y
        // Postcondition: The Date is changed to the specified month, day and year
        public void SetDate(int m, int d, int y)
        {
            Month = m; // set the Month property
            Day = d; // set the Day property
            Year = y; // set the Year property
        }

        public int Month
        {
            // Precondition: None
            // Postcondition: The month will be returned
            get
            {
                return _month;
            }

            // Precondition: 0 < value <= 12
            // Postcondition: The month has been set to the specified value
            set
            {
                if (value > 0 && value <= 12)
                    _month = value;
                else // When invalid, month is set to 1
                    _month = 1;
            }
        }
        
        public int Day
        {
            // Precondition:  None
            // Postcondition: The day has been returned
            get
            {
                return _day;
            }

            // Precondition:  0 < value <= 31
            // Postcondition: The day has been set to the specified value
            set
            {
                if (value > 0 && value <= 31)
                    _day = value;
                else // When invalid, day is set to 1
                    _day = 1;
            }
        }

        public int Year
        {
            // Precondition:  None
            // Postcondition: The year has been returned
            get
            {
                return _year;
            }

            // Precondition:  value >= 0
            // Postcondition: The year has been set to the specified value
            set
            {
                if (value >= 0)
                    _year = value;
                else // When invalid, year is set to 2000
                    _year = 2000;
            }
        }

        // Precondition:  None
        // Postcondition: A string is returned presenting the date as MM/DD/YYYY
        public override string ToString()
        {
            string result;

            result = Month.ToString("D2") + "/" + Day.ToString("D2") + "/" +
                Year.ToString("D4");

            return result;
        }
    }
}