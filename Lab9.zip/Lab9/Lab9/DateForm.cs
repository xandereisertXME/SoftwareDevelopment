﻿// ID: B8994
// Lab 9
// Due: 18 April 2017
// CIS 199-02

// Description: This program uses a custom Date object to form a date
// in the MM/DD/YYYY format through use of properties.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class DateForm : Form
    {
        // Date object field at default date 1/1/2000
        private Date currentDate = new Date(1,1,2000);

        public DateForm()
        {
            InitializeComponent();
        }

        // Set default date on load
        private void DateForm_Load(object sender, EventArgs e)
        {
            dateOutputLabel.Text = currentDate.ToString();
        }

        // Set month from month textbox
        private void monthButton_Click(object sender, EventArgs e)
        {
            int month = 1;

            if (int.TryParse(monthTextBox.Text, out month))
            {
                currentDate.Month = month;
                monthTextBox.Text = "";
                dateOutputLabel.Text = currentDate.ToString();
            }

            else
            {
                MessageBox.Show("Invalid Month!");
                monthTextBox.Text = "";
            }
        }

        // Set day from day textbox
        private void dayButton_Click(object sender, EventArgs e)
        {
            int day = 1;

            if (int.TryParse(dayTextBox.Text, out day))
            {
                currentDate.Day = day;
                dayTextBox.Text = "";
                dateOutputLabel.Text = currentDate.ToString();
            }

            else
            {
                MessageBox.Show("Invalid Day!");
                dayTextBox.Text = "";
            }
        }

        // Set year from year textbox
        private void yearButton_Click(object sender, EventArgs e)
        {
            int year = 2000;

            if (int.TryParse(yearTextBox.Text, out year))
            {
                currentDate.Year = year;
                yearTextBox.Text = "";
                dateOutputLabel.Text = currentDate.ToString();
            }

            else
            {
                MessageBox.Show("Invalid Year!");
                yearTextBox.Text = "";
            }
        }
    }
}
