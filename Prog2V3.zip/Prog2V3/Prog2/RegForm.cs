﻿// Program 2
// CIS 199-05
// Due: 3/7/2017
// ID: B8994

// Description: This program is an incremental update on Program 2 Rev 3, and it adds
// parallel arrays and range matching to complete the same task.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration

            const string TIME1 = "8:30 AM";  // 1st time block
            const string TIME2 = "10:00 AM"; // 2nd time block
            const string TIME3 = "11:30 AM"; // 3rd time block
            const string TIME4 = "2:00 PM";  // 4th time block
            const string TIME5 = "4:00 PM";  // 5th time block

            string[] lower = { TIME5, TIME1, TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4 };
            string[] upper = { TIME3, TIME3, TIME4, TIME4, TIME5, TIME5, TIME1, TIME1, TIME2, TIME2 };
            char[] names = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' };

            string lastNameString;    // Last name
            char lastNameLetterCh;    // First letter last name
            string dateStr = "Error"; // Date of registration
            string timeStr = "Error"; // Time of registration


            lastNameString = lastNameTxt.Text;

            if (lastNameString == "") // Empty text box
                MessageBox.Show("Enter a name");
            else
            {
                lastNameLetterCh = lastNameString[0]; // As in text, p. 466-467

                if (!char.IsLetter(lastNameLetterCh)) // Is it a letter or not?
                    MessageBox.Show("Enter a valid name");
                else
                {
                    lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                    // Juniors and Seniors share same schedule but different days
                    if (juniorRBtn.Checked || seniorRBtn.Checked)
                    {
                        if (seniorRBtn.Checked)
                            dateStr = DAY1;
                        else // Must be juniors
                            dateStr = DAY2;

                        int i = names.Length - 1;
                        while (i >= 0 && lastNameLetterCh < names[i])
                            --i;
                        timeStr = upper[i];
                    }


                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY4;
                            else // All other letters on previous day
                                dateStr = DAY3;
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY6;
                            else // All other letters on previous day
                                dateStr = DAY5;
                        }

                        int i = names.Length - 1;
                        while (i >= 0 && lastNameLetterCh < names[i])
                            --i;
                        timeStr = lower[i];
                    }

                    dateTimeLbl.Text = dateStr + " at " + timeStr;
                }
            }
        }
    }
}

