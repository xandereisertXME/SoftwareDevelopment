﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sqFtTextLabel = new System.Windows.Forms.Label();
            this.numCoatsLabel = new System.Windows.Forms.Label();
            this.paintPerGallonLabel = new System.Windows.Forms.Label();
            this.totalSqFootLabel = new System.Windows.Forms.Label();
            this.galPaintReqLabel = new System.Windows.Forms.Label();
            this.hrsLaborLabel = new System.Windows.Forms.Label();
            this.costPaintLabel = new System.Windows.Forms.Label();
            this.costLaborLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.squareFeetTextbox = new System.Windows.Forms.TextBox();
            this.coatsPaintTextbox = new System.Windows.Forms.TextBox();
            this.pricePerGalTextbox = new System.Windows.Forms.TextBox();
            this.outputSquareFeetLabel = new System.Windows.Forms.Label();
            this.outputGallonsNeededLabel = new System.Windows.Forms.Label();
            this.outputHoursLaborLabel = new System.Windows.Forms.Label();
            this.outputCostPaintLabel = new System.Windows.Forms.Label();
            this.outputCostLaborLabel = new System.Windows.Forms.Label();
            this.outputTotalLabel = new System.Windows.Forms.Label();
            this.paintPictureBox = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pleaseEnterNumbersLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.paintPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // sqFtTextLabel
            // 
            this.sqFtTextLabel.AutoSize = true;
            this.sqFtTextLabel.Location = new System.Drawing.Point(364, 81);
            this.sqFtTextLabel.Name = "sqFtTextLabel";
            this.sqFtTextLabel.Size = new System.Drawing.Size(311, 25);
            this.sqFtTextLabel.TabIndex = 0;
            this.sqFtTextLabel.Text = "Total square feet to be painted:";
            // 
            // numCoatsLabel
            // 
            this.numCoatsLabel.AutoSize = true;
            this.numCoatsLabel.Location = new System.Drawing.Point(423, 150);
            this.numCoatsLabel.Name = "numCoatsLabel";
            this.numCoatsLabel.Size = new System.Drawing.Size(252, 25);
            this.numCoatsLabel.TabIndex = 1;
            this.numCoatsLabel.Text = "Number of coats of paint:";
            // 
            // paintPerGallonLabel
            // 
            this.paintPerGallonLabel.AutoSize = true;
            this.paintPerGallonLabel.Location = new System.Drawing.Point(430, 219);
            this.paintPerGallonLabel.Name = "paintPerGallonLabel";
            this.paintPerGallonLabel.Size = new System.Drawing.Size(245, 25);
            this.paintPerGallonLabel.TabIndex = 2;
            this.paintPerGallonLabel.Text = "Price per gallon of paint:";
            // 
            // totalSqFootLabel
            // 
            this.totalSqFootLabel.AutoSize = true;
            this.totalSqFootLabel.Location = new System.Drawing.Point(328, 355);
            this.totalSqFootLabel.Name = "totalSqFootLabel";
            this.totalSqFootLabel.Size = new System.Drawing.Size(347, 25);
            this.totalSqFootLabel.TabIndex = 3;
            this.totalSqFootLabel.Text = "Total square footage to be painted:";
            // 
            // galPaintReqLabel
            // 
            this.galPaintReqLabel.AutoSize = true;
            this.galPaintReqLabel.Location = new System.Drawing.Point(429, 424);
            this.galPaintReqLabel.Name = "galPaintReqLabel";
            this.galPaintReqLabel.Size = new System.Drawing.Size(246, 25);
            this.galPaintReqLabel.TabIndex = 4;
            this.galPaintReqLabel.Text = "Gallons of paint needed:";
            // 
            // hrsLaborLabel
            // 
            this.hrsLaborLabel.AutoSize = true;
            this.hrsLaborLabel.Location = new System.Drawing.Point(437, 493);
            this.hrsLaborLabel.Name = "hrsLaborLabel";
            this.hrsLaborLabel.Size = new System.Drawing.Size(238, 25);
            this.hrsLaborLabel.TabIndex = 5;
            this.hrsLaborLabel.Text = "Hours of labor required:";
            // 
            // costPaintLabel
            // 
            this.costPaintLabel.AutoSize = true;
            this.costPaintLabel.Location = new System.Drawing.Point(500, 562);
            this.costPaintLabel.Name = "costPaintLabel";
            this.costPaintLabel.Size = new System.Drawing.Size(175, 25);
            this.costPaintLabel.TabIndex = 6;
            this.costPaintLabel.Text = "Cost of the paint:";
            // 
            // costLaborLabel
            // 
            this.costLaborLabel.AutoSize = true;
            this.costLaborLabel.Location = new System.Drawing.Point(499, 631);
            this.costLaborLabel.Name = "costLaborLabel";
            this.costLaborLabel.Size = new System.Drawing.Size(176, 25);
            this.costLaborLabel.TabIndex = 7;
            this.costLaborLabel.Text = "Cost of the labor:";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(586, 718);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(89, 31);
            this.totalLabel.TabIndex = 8;
            this.totalLabel.Text = "Total:";
            // 
            // squareFeetTextbox
            // 
            this.squareFeetTextbox.Location = new System.Drawing.Point(694, 78);
            this.squareFeetTextbox.Name = "squareFeetTextbox";
            this.squareFeetTextbox.Size = new System.Drawing.Size(300, 31);
            this.squareFeetTextbox.TabIndex = 9;
            // 
            // coatsPaintTextbox
            // 
            this.coatsPaintTextbox.Location = new System.Drawing.Point(694, 150);
            this.coatsPaintTextbox.Name = "coatsPaintTextbox";
            this.coatsPaintTextbox.Size = new System.Drawing.Size(300, 31);
            this.coatsPaintTextbox.TabIndex = 10;
            // 
            // pricePerGalTextbox
            // 
            this.pricePerGalTextbox.Location = new System.Drawing.Point(694, 216);
            this.pricePerGalTextbox.Name = "pricePerGalTextbox";
            this.pricePerGalTextbox.Size = new System.Drawing.Size(300, 31);
            this.pricePerGalTextbox.TabIndex = 11;
            // 
            // outputSquareFeetLabel
            // 
            this.outputSquareFeetLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputSquareFeetLabel.Location = new System.Drawing.Point(689, 355);
            this.outputSquareFeetLabel.Name = "outputSquareFeetLabel";
            this.outputSquareFeetLabel.Size = new System.Drawing.Size(300, 31);
            this.outputSquareFeetLabel.TabIndex = 12;
            // 
            // outputGallonsNeededLabel
            // 
            this.outputGallonsNeededLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputGallonsNeededLabel.Location = new System.Drawing.Point(689, 424);
            this.outputGallonsNeededLabel.Name = "outputGallonsNeededLabel";
            this.outputGallonsNeededLabel.Size = new System.Drawing.Size(300, 31);
            this.outputGallonsNeededLabel.TabIndex = 13;
            // 
            // outputHoursLaborLabel
            // 
            this.outputHoursLaborLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputHoursLaborLabel.Location = new System.Drawing.Point(689, 493);
            this.outputHoursLaborLabel.Name = "outputHoursLaborLabel";
            this.outputHoursLaborLabel.Size = new System.Drawing.Size(300, 31);
            this.outputHoursLaborLabel.TabIndex = 14;
            // 
            // outputCostPaintLabel
            // 
            this.outputCostPaintLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputCostPaintLabel.Location = new System.Drawing.Point(689, 562);
            this.outputCostPaintLabel.Name = "outputCostPaintLabel";
            this.outputCostPaintLabel.Size = new System.Drawing.Size(300, 31);
            this.outputCostPaintLabel.TabIndex = 15;
            // 
            // outputCostLaborLabel
            // 
            this.outputCostLaborLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputCostLaborLabel.Location = new System.Drawing.Point(689, 631);
            this.outputCostLaborLabel.Name = "outputCostLaborLabel";
            this.outputCostLaborLabel.Size = new System.Drawing.Size(300, 31);
            this.outputCostLaborLabel.TabIndex = 16;
            // 
            // outputTotalLabel
            // 
            this.outputTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputTotalLabel.Location = new System.Drawing.Point(689, 723);
            this.outputTotalLabel.Name = "outputTotalLabel";
            this.outputTotalLabel.Size = new System.Drawing.Size(300, 31);
            this.outputTotalLabel.TabIndex = 17;
            // 
            // paintPictureBox
            // 
            this.paintPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("paintPictureBox.Image")));
            this.paintPictureBox.Location = new System.Drawing.Point(43, 424);
            this.paintPictureBox.Name = "paintPictureBox";
            this.paintPictureBox.Size = new System.Drawing.Size(325, 346);
            this.paintPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.paintPictureBox.TabIndex = 18;
            this.paintPictureBox.TabStop = false;
            this.paintPictureBox.Click += new System.EventHandler(this.paintPictureBox_Click);
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(43, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(325, 139);
            this.label7.TabIndex = 19;
            this.label7.Text = "Click the paint can to calculate your costs!";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pleaseEnterNumbersLabel
            // 
            this.pleaseEnterNumbersLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pleaseEnterNumbersLabel.Location = new System.Drawing.Point(113, 52);
            this.pleaseEnterNumbersLabel.Name = "pleaseEnterNumbersLabel";
            this.pleaseEnterNumbersLabel.Size = new System.Drawing.Size(182, 82);
            this.pleaseEnterNumbersLabel.TabIndex = 20;
            this.pleaseEnterNumbersLabel.Text = "Please only enter numbers into this program";
            this.pleaseEnterNumbersLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 803);
            this.Controls.Add(this.pleaseEnterNumbersLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.paintPictureBox);
            this.Controls.Add(this.outputTotalLabel);
            this.Controls.Add(this.outputCostLaborLabel);
            this.Controls.Add(this.outputCostPaintLabel);
            this.Controls.Add(this.outputHoursLaborLabel);
            this.Controls.Add(this.outputGallonsNeededLabel);
            this.Controls.Add(this.outputSquareFeetLabel);
            this.Controls.Add(this.pricePerGalTextbox);
            this.Controls.Add(this.coatsPaintTextbox);
            this.Controls.Add(this.squareFeetTextbox);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.costLaborLabel);
            this.Controls.Add(this.costPaintLabel);
            this.Controls.Add(this.hrsLaborLabel);
            this.Controls.Add(this.galPaintReqLabel);
            this.Controls.Add(this.totalSqFootLabel);
            this.Controls.Add(this.paintPerGallonLabel);
            this.Controls.Add(this.numCoatsLabel);
            this.Controls.Add(this.sqFtTextLabel);
            this.Name = "Form1";
            this.Text = "Program 1";
            ((System.ComponentModel.ISupportInitialize)(this.paintPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sqFtTextLabel;
        private System.Windows.Forms.Label numCoatsLabel;
        private System.Windows.Forms.Label paintPerGallonLabel;
        private System.Windows.Forms.Label totalSqFootLabel;
        private System.Windows.Forms.Label galPaintReqLabel;
        private System.Windows.Forms.Label hrsLaborLabel;
        private System.Windows.Forms.Label costPaintLabel;
        private System.Windows.Forms.Label costLaborLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox squareFeetTextbox;
        private System.Windows.Forms.TextBox coatsPaintTextbox;
        private System.Windows.Forms.TextBox pricePerGalTextbox;
        private System.Windows.Forms.Label outputSquareFeetLabel;
        private System.Windows.Forms.Label outputGallonsNeededLabel;
        private System.Windows.Forms.Label outputHoursLaborLabel;
        private System.Windows.Forms.Label outputCostPaintLabel;
        private System.Windows.Forms.Label outputCostLaborLabel;
        private System.Windows.Forms.Label outputTotalLabel;
        private System.Windows.Forms.PictureBox paintPictureBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label pleaseEnterNumbersLabel;
    }
}

