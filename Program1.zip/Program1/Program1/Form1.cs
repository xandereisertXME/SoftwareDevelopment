﻿// ID: B8994
// Program 1
// Due: 14 February 2017
// CIS 199-02

// Description: This program calculates the costs associated with painting a room
// based on square footage of the room, the square footage that one gallon of paint
// can cover, the time a worker takes to paint that amount of wall space, etc. The
// program prompts the user for the total square footage that they would like painted,
// the number of coats they would like put on, and the cost of their paint per gallon.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void paintPictureBox_Click(object sender, EventArgs e)
        {

            // Declaring constants
            const decimal SQUARE_FEET_RATE = 330m;
            const decimal HOURS_RATE = 6m;
            const decimal LABOR_CHARGE_RATE = 10.50m;

            // Declaring all user input variables
            float SQUARE_FEET;         // Square footage from the text box
            int COATS_OF_PAINT;        // Coats of paint from the text box
            float COST_PER_GAL;        // Cost per gallon of paint from the text box

            // Declaring all output label variables
            float TOTAL_SQUARE_FEET;   // Total square feet to be painted
            float NUMBER_GALLONS;      // Gallons of paint required, rounded to the next gallon up
            float HOURS_OF_LABOR;      // Hours of labor required, rounded to 1 decimal point
            float COST_OF_PAINT;       // Cost of the paint
            float COST_OF_LABOR;       // Cost of the labor
            float COST_TOTAL;          // Total cost in the end

            // Assigning all 3 textbox values to their respective variables 
            SQUARE_FEET = float.Parse(squareFeetTextbox.Text);
            COATS_OF_PAINT = int.Parse(coatsPaintTextbox.Text);
            COST_PER_GAL = float.Parse(pricePerGalTextbox.Text);

            // Total square feet calculation
            TOTAL_SQUARE_FEET = SQUARE_FEET * COATS_OF_PAINT;
            outputSquareFeetLabel.Text = TOTAL_SQUARE_FEET.ToString("n1");

            // Total gallons of paint needed calculation
            NUMBER_GALLONS = TOTAL_SQUARE_FEET / (float)SQUARE_FEET_RATE;
            outputGallonsNeededLabel.Text = Math.Ceiling(NUMBER_GALLONS).ToString("n0");

            // Total hours of labor calculation
            HOURS_OF_LABOR = (float)HOURS_RATE * NUMBER_GALLONS;
            outputHoursLaborLabel.Text = HOURS_OF_LABOR.ToString("n1");

            // Total cost of paint calculation
            COST_OF_PAINT = COST_PER_GAL * float.Parse(outputGallonsNeededLabel.Text);
            outputCostPaintLabel.Text = COST_OF_PAINT.ToString("c");

            // Total cost of labor calculation
            COST_OF_LABOR = HOURS_OF_LABOR * (float)LABOR_CHARGE_RATE;
            outputCostLaborLabel.Text = COST_OF_LABOR.ToString("c");

            // Total overall cost calculation
            COST_TOTAL = COST_OF_PAINT + COST_OF_LABOR;
            outputTotalLabel.Text = COST_TOTAL.ToString("c");

        }
    }
}
