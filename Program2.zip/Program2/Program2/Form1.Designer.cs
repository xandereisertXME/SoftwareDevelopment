﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gradeGroupBox = new System.Windows.Forms.GroupBox();
            this.freshmanRadio = new System.Windows.Forms.RadioButton();
            this.sophomoreRadio = new System.Windows.Forms.RadioButton();
            this.juniorRadio = new System.Windows.Forms.RadioButton();
            this.seniorRadio = new System.Windows.Forms.RadioButton();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.registerButton = new System.Windows.Forms.Button();
            this.gradeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // gradeGroupBox
            // 
            this.gradeGroupBox.Controls.Add(this.seniorRadio);
            this.gradeGroupBox.Controls.Add(this.juniorRadio);
            this.gradeGroupBox.Controls.Add(this.sophomoreRadio);
            this.gradeGroupBox.Controls.Add(this.freshmanRadio);
            this.gradeGroupBox.Location = new System.Drawing.Point(45, 38);
            this.gradeGroupBox.Name = "gradeGroupBox";
            this.gradeGroupBox.Size = new System.Drawing.Size(228, 286);
            this.gradeGroupBox.TabIndex = 0;
            this.gradeGroupBox.TabStop = false;
            this.gradeGroupBox.Text = "1. Select Your Grade";
            // 
            // freshmanRadio
            // 
            this.freshmanRadio.AutoSize = true;
            this.freshmanRadio.Location = new System.Drawing.Point(19, 60);
            this.freshmanRadio.Name = "freshmanRadio";
            this.freshmanRadio.Size = new System.Drawing.Size(139, 29);
            this.freshmanRadio.TabIndex = 0;
            this.freshmanRadio.TabStop = true;
            this.freshmanRadio.Text = "Freshman";
            this.freshmanRadio.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadio
            // 
            this.sophomoreRadio.AutoSize = true;
            this.sophomoreRadio.Location = new System.Drawing.Point(19, 120);
            this.sophomoreRadio.Name = "sophomoreRadio";
            this.sophomoreRadio.Size = new System.Drawing.Size(153, 29);
            this.sophomoreRadio.TabIndex = 1;
            this.sophomoreRadio.TabStop = true;
            this.sophomoreRadio.Text = "Sophomore";
            this.sophomoreRadio.UseVisualStyleBackColor = true;
            // 
            // juniorRadio
            // 
            this.juniorRadio.AutoSize = true;
            this.juniorRadio.Location = new System.Drawing.Point(19, 180);
            this.juniorRadio.Name = "juniorRadio";
            this.juniorRadio.Size = new System.Drawing.Size(102, 29);
            this.juniorRadio.TabIndex = 2;
            this.juniorRadio.TabStop = true;
            this.juniorRadio.Text = "Junior";
            this.juniorRadio.UseVisualStyleBackColor = true;
            // 
            // seniorRadio
            // 
            this.seniorRadio.AutoSize = true;
            this.seniorRadio.Location = new System.Drawing.Point(19, 240);
            this.seniorRadio.Name = "seniorRadio";
            this.seniorRadio.Size = new System.Drawing.Size(105, 29);
            this.seniorRadio.TabIndex = 3;
            this.seniorRadio.TabStop = true;
            this.seniorRadio.Text = "Senior";
            this.seniorRadio.UseVisualStyleBackColor = true;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(328, 38);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(234, 25);
            this.lastNameLabel.TabIndex = 4;
            this.lastNameLabel.Text = "2. Enter your last name";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(333, 80);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(234, 31);
            this.lastNameTextBox.TabIndex = 5;
            // 
            // registerButton
            // 
            this.registerButton.Location = new System.Drawing.Point(321, 172);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(264, 54);
            this.registerButton.TabIndex = 6;
            this.registerButton.Text = "Show Registration Date";
            this.registerButton.UseVisualStyleBackColor = true;
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.registerButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 363);
            this.Controls.Add(this.registerButton);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.gradeGroupBox);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.gradeGroupBox.ResumeLayout(false);
            this.gradeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gradeGroupBox;
        private System.Windows.Forms.RadioButton seniorRadio;
        private System.Windows.Forms.RadioButton juniorRadio;
        private System.Windows.Forms.RadioButton sophomoreRadio;
        private System.Windows.Forms.RadioButton freshmanRadio;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Button registerButton;
    }
}

