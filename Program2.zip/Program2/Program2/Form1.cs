﻿// ID: B8994
// Program 2
// Due: 9 March 2017
// CIS 199-02

// Description: This program is a version of the UofL Registrar's tool that lets students know
// when their registration slot for Fall 2017 opens up. The program works with all grades from
// freshmen to seniors, and the user can select their grade level with RadioButton controls to
// determine the date of their registration. The program also requires the entry of the user's 
// last name into a TextBox, from which the program captures the first letter to determine the
// specific time slot for registration.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void registerButton_Click(object sender, EventArgs e)
        {

            // Constants declared for grades and the dates on which they can register
            const string FRESHMAN_REG_1 = "Tuesday, April 4th";     // Freshman registration date 1
            const string FRESHMAN_REG_2 = "Wednesday, April 5th";   // Freshman registratoin date 2
            const string SOPHOMORE_REG_1 = "Friday, March 31st";    // Sophomore registration date 1
            const string SOPHOMORE_REG_2 = "Monday, April 3rd";     // Sophomore registration date 2
            const string JUNIOR_REG = "Thursday, March 30th";       // Junior registration date
            const string SENIOR_REG = "Wednesday, March 29th";      // Senior registration date

            // Constants declared for five different time slots for registration, based on 
            // the first letter of a student's last name
            const string TIME_1 = " 8:30 AM";     // First registration time
            const string TIME_2 = " 10:00 AM";    // Second registration time
            const string TIME_3 = " 11:30 AM";    // Third registration time
            const string TIME_4 = " 2:00 PM";     // Fourth registration time
            const string TIME_5 = " 4:00 PM";     // Fifth registration time

            // Checks whether the TextBox has any value entered
            if (lastNameTextBox.TextLength <= 0)
            {
                MessageBox.Show("Please enter your last name in the TextBox");
            }
            else
            {
                // Retrieving the first character of the last name
                char lastName = (lastNameTextBox.Text)[0];     // Variable will store the value from the textbox
                lastName = char.ToUpper(lastName);             // Converting to uppercase to keep value consistent


                // Freshman Check
                if (freshmanRadio.Checked)
                    if (lastName >= 'P' && lastName <= 'Q')
                        MessageBox.Show(FRESHMAN_REG_1 + TIME_1);
                    else
                    {
                        if (lastName >= 'R' && lastName <= 'S')
                            MessageBox.Show(FRESHMAN_REG_1 + TIME_2);
                        else
                        {
                            if (lastName >= 'T' && lastName <= 'V')
                                MessageBox.Show(FRESHMAN_REG_1 + TIME_3);
                            else
                            {
                                if (lastName >= 'W' && lastName <= 'Z')
                                    MessageBox.Show(FRESHMAN_REG_1 + TIME_4);
                                else
                                {
                                    if (lastName >= 'A' && lastName <= 'B')
                                        MessageBox.Show(FRESHMAN_REG_1 + TIME_5);
                                    else
                                    {
                                        if (lastName >= 'C' && lastName <= 'D')
                                            MessageBox.Show(FRESHMAN_REG_2 + TIME_1);
                                        else
                                        {
                                            if (lastName >= 'E' && lastName <= 'F')
                                                MessageBox.Show(FRESHMAN_REG_2 + TIME_2);
                                            else
                                            {
                                                if (lastName >= 'G' && lastName <= 'I')
                                                    MessageBox.Show(FRESHMAN_REG_2 + TIME_3);
                                                else
                                                {
                                                    if (lastName >= 'J' && lastName <= 'L')
                                                        MessageBox.Show(FRESHMAN_REG_2 + TIME_4);
                                                    else
                                                        MessageBox.Show(FRESHMAN_REG_2 + TIME_5);
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }

                // Sophomore Check
                if (sophomoreRadio.Checked)
                    if (lastName >= 'P' && lastName <= 'Q')
                        MessageBox.Show(SOPHOMORE_REG_1 + TIME_1);
                    else
                    {
                        if (lastName >= 'R' && lastName <= 'S')
                            MessageBox.Show(SOPHOMORE_REG_1 + TIME_2);
                        else
                        {
                            if (lastName >= 'T' && lastName <= 'V')
                                MessageBox.Show(SOPHOMORE_REG_1 + TIME_3);
                            else
                            {
                                if (lastName >= 'W' && lastName <= 'Z')
                                    MessageBox.Show(SOPHOMORE_REG_1 + TIME_4);
                                else
                                {
                                    if (lastName >= 'A' && lastName <= 'B')
                                        MessageBox.Show(SOPHOMORE_REG_1 + TIME_5);
                                    else
                                    {
                                        if (lastName >= 'C' && lastName <= 'D')
                                            MessageBox.Show(SOPHOMORE_REG_2 + TIME_1);
                                        else
                                        {
                                            if (lastName >= 'E' && lastName <= 'F')
                                                MessageBox.Show(SOPHOMORE_REG_2 + TIME_2);
                                            else
                                            {
                                                if (lastName >= 'G' && lastName <= 'I')
                                                    MessageBox.Show(SOPHOMORE_REG_2 + TIME_3);
                                                else
                                                {
                                                    if (lastName >= 'J' && lastName <= 'L')
                                                        MessageBox.Show(SOPHOMORE_REG_2 + TIME_4);
                                                    else
                                                        MessageBox.Show(SOPHOMORE_REG_2 + TIME_5);
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }

                // Junior Check
                if (juniorRadio.Checked)
                    if (lastName >= 'P' && lastName <= 'S')
                        MessageBox.Show(JUNIOR_REG + TIME_1);
                    else
                    {
                        if (lastName >= 'T' && lastName <= 'Z')
                            MessageBox.Show(JUNIOR_REG + TIME_2);
                        else
                        {
                            if (lastName >= 'A' && lastName <= 'D')
                                MessageBox.Show(JUNIOR_REG + TIME_3);
                            else
                            {
                                if (lastName >= 'E' && lastName <= 'I')
                                    MessageBox.Show(JUNIOR_REG + TIME_4);
                                else
                                {
                                    if (lastName >= 'J' && lastName <= 'O')
                                        MessageBox.Show(JUNIOR_REG + TIME_5);
                                }
                            }
                        }
                    }

                // Senior Check
                if (seniorRadio.Checked)
                    if (lastName >= 'P' && lastName <= 'S')
                        MessageBox.Show(SENIOR_REG + TIME_1);
                    else
                    {
                        if (lastName >= 'T' && lastName <= 'Z')
                            MessageBox.Show(SENIOR_REG + TIME_2);
                        else
                        {
                            if (lastName >= 'A' && lastName <= 'D')
                                MessageBox.Show(SENIOR_REG + TIME_3);
                            else
                            {
                                if (lastName >= 'E' && lastName <= 'I')
                                    MessageBox.Show(SENIOR_REG + TIME_4);
                                else
                                {
                                    if (lastName >= 'J' && lastName <= 'O')
                                        MessageBox.Show(SENIOR_REG + TIME_5);
                                }
                            }
                        }
                    }
            }
        }
    }
}
