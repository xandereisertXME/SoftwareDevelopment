﻿namespace Program4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packageListBox = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.toButton = new System.Windows.Forms.Button();
            this.fromButton = new System.Windows.Forms.Button();
            this.originTextBox = new System.Windows.Forms.TextBox();
            this.destinationTextBox = new System.Windows.Forms.TextBox();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.addPackageButton = new System.Windows.Forms.Button();
            this.originLabel = new System.Windows.Forms.Label();
            this.destinationLabel = new System.Windows.Forms.Label();
            this.lenLabel = new System.Windows.Forms.Label();
            this.widthlabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // packageListBox
            // 
            this.packageListBox.FormattingEnabled = true;
            this.packageListBox.ItemHeight = 25;
            this.packageListBox.Location = new System.Drawing.Point(432, 34);
            this.packageListBox.Name = "packageListBox";
            this.packageListBox.Size = new System.Drawing.Size(456, 379);
            this.packageListBox.TabIndex = 0;
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(938, 34);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(181, 69);
            this.detailsButton.TabIndex = 1;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // toButton
            // 
            this.toButton.Location = new System.Drawing.Point(938, 189);
            this.toButton.Name = "toButton";
            this.toButton.Size = new System.Drawing.Size(181, 69);
            this.toButton.TabIndex = 2;
            this.toButton.Text = "Send to UofL";
            this.toButton.UseVisualStyleBackColor = true;
            this.toButton.Click += new System.EventHandler(this.toButton_Click);
            // 
            // fromButton
            // 
            this.fromButton.Location = new System.Drawing.Point(938, 344);
            this.fromButton.Name = "fromButton";
            this.fromButton.Size = new System.Drawing.Size(181, 69);
            this.fromButton.TabIndex = 3;
            this.fromButton.Text = "Send from UofL";
            this.fromButton.UseVisualStyleBackColor = true;
            this.fromButton.Click += new System.EventHandler(this.fromButton_Click);
            // 
            // originTextBox
            // 
            this.originTextBox.Location = new System.Drawing.Point(194, 34);
            this.originTextBox.Name = "originTextBox";
            this.originTextBox.Size = new System.Drawing.Size(200, 31);
            this.originTextBox.TabIndex = 4;
            // 
            // destinationTextBox
            // 
            this.destinationTextBox.Location = new System.Drawing.Point(194, 103);
            this.destinationTextBox.Name = "destinationTextBox";
            this.destinationTextBox.Size = new System.Drawing.Size(200, 31);
            this.destinationTextBox.TabIndex = 5;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(194, 172);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(200, 31);
            this.lengthTextBox.TabIndex = 6;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(194, 241);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(200, 31);
            this.widthTextBox.TabIndex = 7;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(194, 310);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(200, 31);
            this.heightTextBox.TabIndex = 8;
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(194, 379);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(200, 31);
            this.weightTextBox.TabIndex = 9;
            // 
            // addPackageButton
            // 
            this.addPackageButton.Location = new System.Drawing.Point(70, 440);
            this.addPackageButton.Name = "addPackageButton";
            this.addPackageButton.Size = new System.Drawing.Size(264, 57);
            this.addPackageButton.TabIndex = 10;
            this.addPackageButton.Text = "Add Ground Package";
            this.addPackageButton.UseVisualStyleBackColor = true;
            this.addPackageButton.Click += new System.EventHandler(this.addPackageButton_Click);
            // 
            // originLabel
            // 
            this.originLabel.AutoSize = true;
            this.originLabel.Location = new System.Drawing.Point(65, 40);
            this.originLabel.Name = "originLabel";
            this.originLabel.Size = new System.Drawing.Size(111, 25);
            this.originLabel.TabIndex = 11;
            this.originLabel.Text = "Origin Zip:";
            // 
            // destinationLabel
            // 
            this.destinationLabel.AutoSize = true;
            this.destinationLabel.Location = new System.Drawing.Point(72, 106);
            this.destinationLabel.Name = "destinationLabel";
            this.destinationLabel.Size = new System.Drawing.Size(104, 25);
            this.destinationLabel.TabIndex = 12;
            this.destinationLabel.Text = "Dest. Zip:";
            // 
            // lenLabel
            // 
            this.lenLabel.AutoSize = true;
            this.lenLabel.Location = new System.Drawing.Point(92, 175);
            this.lenLabel.Name = "lenLabel";
            this.lenLabel.Size = new System.Drawing.Size(84, 25);
            this.lenLabel.TabIndex = 13;
            this.lenLabel.Text = "Length:";
            // 
            // widthlabel
            // 
            this.widthlabel.AutoSize = true;
            this.widthlabel.Location = new System.Drawing.Point(103, 244);
            this.widthlabel.Name = "widthlabel";
            this.widthlabel.Size = new System.Drawing.Size(73, 25);
            this.widthlabel.TabIndex = 14;
            this.widthlabel.Text = "Width:";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(96, 310);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(80, 25);
            this.heightLabel.TabIndex = 15;
            this.heightLabel.Text = "Height:";
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Location = new System.Drawing.Point(91, 382);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(85, 25);
            this.weightLabel.TabIndex = 16;
            this.weightLabel.Text = "Weight:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 519);
            this.Controls.Add(this.weightLabel);
            this.Controls.Add(this.heightLabel);
            this.Controls.Add(this.widthlabel);
            this.Controls.Add(this.lenLabel);
            this.Controls.Add(this.destinationLabel);
            this.Controls.Add(this.originLabel);
            this.Controls.Add(this.addPackageButton);
            this.Controls.Add(this.weightTextBox);
            this.Controls.Add(this.heightTextBox);
            this.Controls.Add(this.widthTextBox);
            this.Controls.Add(this.lengthTextBox);
            this.Controls.Add(this.destinationTextBox);
            this.Controls.Add(this.originTextBox);
            this.Controls.Add(this.fromButton);
            this.Controls.Add(this.toButton);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.packageListBox);
            this.Name = "Form1";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox packageListBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button toButton;
        private System.Windows.Forms.Button fromButton;
        private System.Windows.Forms.TextBox originTextBox;
        private System.Windows.Forms.TextBox destinationTextBox;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.Button addPackageButton;
        private System.Windows.Forms.Label originLabel;
        private System.Windows.Forms.Label destinationLabel;
        private System.Windows.Forms.Label lenLabel;
        private System.Windows.Forms.Label widthlabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label weightLabel;
    }
}

