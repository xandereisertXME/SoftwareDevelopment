﻿// ID: B8994
// Program 4
// Due: 25 April 2017
// CIS 199-02

// Description: This program creates a new object, GroundPackage, and allows users to
// add properties to the objects as long as they're valid.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class Form1 : Form
    {
        // List to hold GroundPackage objects
        // Will be kept parallel with strings in packageListBox
        private List<GroundPackage> packageList = new List<GroundPackage>();

        public Form1()
        {
            InitializeComponent();
        }

        // Precondition:  None
        // Postcondition: Form's data are gathered/parsed and out parameters hold data entered.
        //                If all fields are valid, true is returned. 
        //                Otherwise, false is returned.
        private bool ValidatePackageData(out int originZip, out int destZip, out double length, out double width, out double height,
            out double weight)
        {
            bool isValid = false; // Are all data fields valid?

            // Get the package's origin zipcode
            if (int.TryParse(originTextBox.Text, out originZip))
            {
                originZip = int.Parse(originTextBox.Text);
            }

            // Get the package's destination zipcode
            if (int.TryParse(destinationTextBox.Text, out destZip))
            {
                destZip = int.Parse(destinationTextBox.Text);
            }

            // Get the package's length
            if (double.TryParse(lengthTextBox.Text, out length))
            {
                length = double.Parse(lengthTextBox.Text);
            }

            // Get the package's width
            if (double.TryParse(widthTextBox.Text, out width))
            {
                width = double.Parse(widthTextBox.Text);
            }

            // Get the package's height
            if (double.TryParse(heightTextBox.Text, out height))
            {
                height = double.Parse(heightTextBox.Text);
            }

            // Get the package's weight
            if (double.TryParse(weightTextBox.Text, out weight))
            {
                weight = double.Parse(weightTextBox.Text);
            }

            // Get the package's price, validate all fields
            if (int.TryParse(originTextBox.Text, out originZip) && (originZip > 0))
            {
                if (int.TryParse(destinationTextBox.Text, out destZip) && (destZip > 0))
                {
                    if (double.TryParse(lengthTextBox.Text, out length) && (length > 0))
                    {
                        if (double.TryParse(widthTextBox.Text, out width) && (width > 0))
                        {
                            if (double.TryParse(heightTextBox.Text, out height) && (height > 0))
                            {
                                if (double.TryParse(weightTextBox.Text, out weight) && (weight > 0))
                                {
                                    isValid = true;
                                }
                                else MessageBox.Show("Invalid Weight");
                            }
                            else MessageBox.Show("Invalid Height");
                        }
                        else MessageBox.Show("Invalid Width");
                    }
                    else MessageBox.Show("Invalid Length");
                }
                else MessageBox.Show("Invalid Destination Zip");
            }
            else MessageBox.Show("Invalid Origin Zip");

            return isValid;
        }

        // Precondition: None
        // Postcondition: a new GroundPackage is added to the list, and all textboxes are cleared
        private void addPackageButton_Click(object sender, EventArgs e)
        {
            GroundPackage myPackage;    // Holds new package from valid data
            int destZip;                // Entered dest zip
            int originZip;              // Entered origin zip
            double length;              // Entered length
            double width;               // Entered width
            double height;              // Entered height
            double weight;              // Entered weight

            // Get and validate the package data
            if (ValidatePackageData(out destZip, out originZip, out length, out width, out height, out weight))
            {
                // Only create when all data are valid!

                // Create new GroundPackage object from entered data
                myPackage = new GroundPackage(destZip, originZip, length, width, height, weight);

                // Add the GroundPackage object to the List
                packageList.Add(myPackage);

                // Add an entry to the list box, using properties from object
                double price;
                price = myPackage.CalcCost();
                packageListBox.Items.Add(price.ToString("C"));

                // Clear the TextBox controls
                destinationTextBox.Clear();
                originTextBox.Clear();
                lengthTextBox.Clear();
                widthTextBox.Clear();
                heightTextBox.Clear();
                weightTextBox.Clear();

                // Reset the focus
                originTextBox.Focus();
            }
        }

        // Precondition: packageListBox index selection is made and button is pressed
        // Postcondition: Selected GroundPackage's information is displayed in a MessageBox
        private void detailsButton_Click(object sender, EventArgs e)
        {
            int index; // Index of the selected item

            index = packageListBox.SelectedIndex;

            if (index >= 0) // Item was selected (otherwise -1)
            {
                // Display the selected item's full information
                MessageBox.Show(packageList[index].ToString());
            }
            else
            {
                MessageBox.Show("Please select a package");
            }
        }

        private void toButton_Click(object sender, EventArgs e)
        {
            int index;      // Index of the selected item
            double price;   // Price placeholder
            index = packageListBox.SelectedIndex;

            packageList[index].DestinationZip = 40292;      // Destination zip changed to that of UofL
            price = packageList[index].CalcCost();
            packageListBox.Items[index] = price.ToString("C");
            MessageBox.Show("Destination Zip has been changed");
        }

        private void fromButton_Click(object sender, EventArgs e)
        {
            int index;      // Index of the selected item
            double price;   // Price placeholder
            index = packageListBox.SelectedIndex;

            packageList[index].OriginZip = 40292;           // Origin zip changed to that of UofL
            price = packageList[index].CalcCost();
            packageListBox.Items[index] = price.ToString("C");
            MessageBox.Show("Origin Zip has been changed");
        }
    }
}