﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {
        private int _destZipCode;       // 5 digits && > 0
        private int _originZipCode;     // 5 digits && > 0
        private double _length;         // > 0
        private double _width;          // > 0
        private double _height;         // > 0
        private double _weight;         // > 0

        public double DIMENSION_PRICE_FACTOR = .20;   // Used for cost calculation
        public double DISTANCE_WEIGHT_FACTOR = .5;    // Used for cost calculation

        // Precondition: 0 <= d <= 99999, 0 <= o <= 99999, l > 0, wi > 0, h > 0, we > 0 
        // Postcondition: the GroundPackage object has been initialized with its six properties

        public GroundPackage(int o = 0, int d = 0, double l = 1.0, double wi = 1.0, double h = 1.0, double we = 1.0)
        {
            OriginZip = o;          // set DestinationZip property
            DestinationZip = d;     // set OriginZip property
            Length = l;             // set Length property
            Width = wi;             // set Width property
            Height = h;             // set Height property
            Weight = we;            // set Weight property
        }

        public int OriginZip
        {
            // Precondition:  None
            // Postcondition: The OriginZip has been returned
            get
            {
                return _originZipCode;
            }

            // Precondition:  0 <= value <= 99999
            // Postcondition: The OriginZip has been set to the specified value
            set
            {
                if (value >= 0 && value <= 99999)
                    _originZipCode = value;
                else // When invalid, set to 90210 instead
                    _originZipCode = 90210;
            }
        }

        public int DestinationZip
        {
            // Precondition:  None
            // Postcondition: The DestinationZip has been returned
            get
            {
                return _destZipCode;
            }

            // Precondition:  0 <= value <= 99999
            // Postcondition: The DestinationZip has been set to the specified value
            set
            {
                if (value >= 0 && value <= 99999)
                    _destZipCode = value;
                else // When invalid, set to 40202 instead
                    _destZipCode = 40202;
            }
        }

        public double Length
        {
            // Precondition: None
            // Postcondition: The Length has been returned
            get
            {
                return _length;
            }

            // Precondition: value > 0
            // Postcondition: The Length has been set to the specified value
            set
            {
                if (value > 0)
                    _length = value;
                else // When invalid, set to 1.0 instead
                    _length = 1.0;
            }
        }

        public double Width
        {
            // Precondition: None
            // Postcondition: The Width has been returned
            get
            {
                return _width;
            }

            // Precondition: value > 0
            // Postcondition: The Width has been set to the specified value
            set
            {
                if (value > 0)
                    _width = value;
                else // When invalid, set to 1.0 instead
                    _width = 1.0;
            }
        }

        public double Height
        {
            // Precondition: None
            // Postcondition: The Height has been returned
            get
            {
                return _height;
            }

            // Precondition: value > 0
            // Postcondition: The Height has been set to the specified value
            set
            {
                if (value > 0)
                    _height = value;
                else // When invalid, set to 1.0 instead
                    _height = 1.0;
            }
        }

        public double Weight
        {
            // Precondition: None
            // Postcondition: The Weight has been returned
            get
            {
                return _weight;
            }

            // Precondition: value > 0
            // Postcondition: The Weight has been set to the specified value
            set
            {
                if (value > 0)
                    _weight = value;
                else // When invalid, set to 1.0 instead
                    _weight = 1.0;
            }
        }

        public int ZoneDistance     // Zone distance between zip codes; calculated with the first digit of the zip codes
        {
            // Precondition: None
            // Postcondition: The ZoneDistance has been returned
            get
            {
                return Math.Abs((OriginZip / 10000) - (DestinationZip / 10000));
            }
        }

        public double CalcCost()
        {
            // Precondition: None
            // Postcondition: The CalcCost (calculated cost of shipping) has been returned
            return DIMENSION_PRICE_FACTOR * (Length + Width + Height) + DISTANCE_WEIGHT_FACTOR * (ZoneDistance + 1) * (Weight);
        }

        public override string ToString()
        {
            string result;  // Holds details of the individual package

            result = "Origin: " + OriginZip.ToString() + System.Environment.NewLine + "Destination: " + DestinationZip.ToString() +
                System.Environment.NewLine + "Length: " + Length.ToString() + System.Environment.NewLine + "Width: " + Width.ToString() +
                System.Environment.NewLine + "Height: " + Height.ToString() + System.Environment.NewLine + "Weight: " + Weight.ToString();

            return result;
        }
    }
}